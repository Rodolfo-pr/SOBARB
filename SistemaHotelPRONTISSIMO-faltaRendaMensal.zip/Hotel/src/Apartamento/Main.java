package Apartamento;
 
import javax.swing.JFrame;

public class Main { 
   public static void main(JFrame args) {
     IUG gui = new IUG(args);
   }
}
