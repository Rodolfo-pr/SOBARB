package DAOs;

import Entidades.Ap;
import java.util.ArrayList;
import java.util.List;

public class DAOAp extends DAOGenerico<Ap> {

    private List<Ap> lista = new ArrayList<>();

    public DAOAp() {
        super(Ap.class);
    }

    public int autoIdAp() {
        Integer a = (Integer) em.createQuery("SELECT MAX(e.nome) FROM Ap e ").getSingleResult();
        if (a != null) {
            return a + 1;
        } else {
            return 1;
        }
    }

    public List<Ap> listByNome(String nome) {
        return em.createQuery("SELECT e FROM Ap e WHERE e.nome) LIKE :nome").setParameter("nome", "%" + nome + "%").getResultList();
    }

    public List<Ap> listById(int id) {
        return em.createQuery("SELECT e FROM Ap + e WHERE e.nome= :id").setParameter("id", id).getResultList();
    }

    public List<Ap> listInOrderNome() {
        return em.createQuery("SELECT e FROM Ap e ORDER BY e.nome").getResultList();
    }

    public List<Ap> listInOrderId() {
        return em.createQuery("SELECT e FROM Ap e ORDER BY e.nome").getResultList();
    }

    public List<String> listInOrderNomeStrings(String qualOrdem) {
        List<Ap> lf;
        if (qualOrdem.equals("id")) {
            lf = listInOrderId();
        } else {
            lf = listInOrderNome();
        }

        List<String> ls = new ArrayList<>();
        for (int i = 0; i < lf.size(); i++) {
            ls.add(lf.get(i).getNome()+ "-" + lf.get(i).getIdade());
        }
        return ls;
    }

    public static void main(String[] args) {
        DAOAp daoAp = new DAOAp();
        List<Ap> listaAp = daoAp.list();
        for (Ap trabalhador : listaAp) {
            System.out.println(trabalhador.getNome()+ "-" + trabalhador.getIdade());
        }
    }
}
